import random
import numpy as np

# Part 1 D
# TODO: set a random seed (do this both from random and for numpy)
# This should be based on the seed that gets sent to you
seed = None
random.seed ( seed )
generator = np.random.RandomState(seed)
